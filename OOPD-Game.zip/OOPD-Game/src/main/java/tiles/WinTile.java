package tiles;

import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.tile.Tile;

public class WinTile extends Tile{

	public WinTile(Sprite sprite) {
		super(sprite);
	}

}
