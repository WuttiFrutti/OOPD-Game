package nl.han.ica.oopg.logger;

/**
 * Indicates the log handler.
 */
public interface LogHandler {
	
    public void logln(int level, String message);
}
